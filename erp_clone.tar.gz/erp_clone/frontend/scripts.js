/*
 * Front‑end logic for the ERP clone. This script initialises the
 * DataTable on the Clients page and loads sample data from a JSON file.
 * In a real application you would replace the $.getJSON call with an
 * AJAX request to your backend API (e.g. /api/clients) that returns
 * an array of client objects.
 */

$(document).ready(function () {
  /*
   * Sample data for the Clients table. When integrating with your backend,
   * remove this hardcoded array and replace it with an AJAX call (e.g.
   * using $.getJSON or fetch) to load client data from the server.
   */
  var sampleData = [
    {
      registration_date: '2025-07-21',
      name: 'ЦИНСЕН',
      abbreviation: null,
      code: null,
      vat_code: null,
      phone: null,
      fax: null,
      email: null,
      website: null
    },
    {
      registration_date: '2025-07-21',
      name: 'ZABKA Z6641 K Z UL ZABRZANSKA KORICHNEVYI SLASKA PL 2',
      abbreviation: null,
      code: null,
      vat_code: null,
      phone: null,
      fax: null,
      email: null,
      website: null
    },
    {
      registration_date: '2023-10-03',
      name: 'Правление государственного фонда социального страхования при Министерстве',
      abbreviation: null,
      code: '1916303223',
      vat_code: 'LT916302219',
      phone: null,
      fax: null,
      email: null,
      website: null
    },
    {
      registration_date: '2025-07-21',
      name: 'Государственная налоговая инспекция при Министерстве финансов Литовской Республики',
      abbreviation: null,
      code: '1886599752',
      vat_code: 'LT886597515',
      phone: null,
      fax: null,
      email: null,
      website: null
    },
    {
      registration_date: '2023-10-03',
      name: 'ЗАО "MAM INVEST"',
      abbreviation: null,
      code: '303047848',
      vat_code: 'LT100007915219',
      phone: null,
      fax: null,
      email: null,
      website: null
    },
    {
      registration_date: '2025-07-21',
      name: 'СВПОЛ/Лл GMx',
      abbreviation: null,
      code: null,
      vat_code: null,
      phone: null,
      fax: null,
      email: null,
      website: null
    },
    {
      registration_date: '2025-07-21',
      name: 'Marazin Dratetsinar 31a Hamburg DE',
      abbreviation: null,
      code: null,
      vat_code: null,
      phone: null,
      fax: null,
      email: null,
      website: null
    },
    {
      registration_date: '2025-07-21',
      name: 'Marazin Dessauer Str 104 Kiten DE',
      abbreviation: null,
      code: null,
      vat_code: null,
      phone: null,
      fax: null,
      email: null,
      website: null
    },
    {
      registration_date: '2025-07-21',
      name: 'SIA Vagonupatates',
      abbreviation: null,
      code: null,
      vat_code: null,
      phone: null,
      fax: null,
      email: null,
      website: null
    },
    {
      registration_date: '2025-07-21',
      name: 'SHELL 6762 Hamburg, Germany',
      abbreviation: null,
      code: null,
      vat_code: null,
      phone: null,
      fax: null,
      email: null,
      website: null
    }
  ];

  // If DataTables is available, initialise the enhanced table. Otherwise fall
  // back to a simple HTML table so that data is still visible without JS
  // dependencies. This ensures the demo works when loaded locally via file://
  // where some browsers restrict script execution.
  if ($.fn.DataTable) {
    $('#clientsTable').DataTable({
      data: sampleData,
      columns: [
        { data: 'registration_date' },
        { data: 'name' },
        { data: 'abbreviation' },
        { data: 'code' },
        { data: 'vat_code' },
        { data: 'phone' },
        { data: 'fax' },
        { data: 'email' },
        { data: 'website' }
      ],
      pageLength: 20,
      lengthMenu: [ [20, 50, 100, -1], [20, 50, 100, 'All'] ],
      order: [[0, 'desc']],
      language: {
        search: 'Search:',
        lengthMenu: 'Show _MENU_ entries',
        info: 'Showing _START_ to _END_ of _TOTAL_ entries',
        infoEmpty: 'No entries to show',
        paginate: {
          previous: 'Prev',
          next: 'Next'
        }
      }
    });
  } else {
    // Fallback: append rows manually
    var tbody = $('#clientsTable tbody');
    sampleData.forEach(function (client) {
      var row = '<tr>' +
        '<td>' + (client.registration_date || '') + '</td>' +
        '<td>' + (client.name || '') + '</td>' +
        '<td>' + (client.abbreviation || '') + '</td>' +
        '<td>' + (client.code || '') + '</td>' +
        '<td>' + (client.vat_code || '') + '</td>' +
        '<td>' + (client.phone || '') + '</td>' +
        '<td>' + (client.fax || '') + '</td>' +
        '<td>' + (client.email || '') + '</td>' +
        '<td>' + (client.website || '') + '</td>' +
        '</tr>';
      tbody.append(row);
    });
  }
});